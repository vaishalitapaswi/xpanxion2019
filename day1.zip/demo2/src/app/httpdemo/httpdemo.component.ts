import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-httpdemo',
  templateUrl: './httpdemo.component.html',
  styleUrls: ['./httpdemo.component.css']
})
export class HttpdemoComponent implements OnInit {

  constructor(private http:HttpClient) { }
  uid:string="1"
  url:string="https://reqres.in/api/unknown/"
  user:object;
  users=[]
  ngOnInit() {
  }
  getuser(){
    console.log("info " + this.uid)
    this.http.get(this.url+this.uid).subscribe(
      (value)=>this.user = value["data"],
      (err)=>this.user ={"uid":"Undefined"}
    )
    console.log("after get")
  }

  getusers(){
    console.log("info " + this.uid)
    this.http.get("https://reqres.in/api/users?page="+ this.uid).subscribe(
      (value)=> {this.users = value["data"]; console.log(this.users)},
      (err)=>this.user ={"uid":"Undefined"}
    )
    console.log("after get")
  }
}
