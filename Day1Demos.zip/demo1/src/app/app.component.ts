import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title:string = 'Vaishali HelloWorld';
  imgname:string="../assets/demo1.png";

  change():void{
    if (this.imgname=="../assets/demo1.png")
      this.imgname= "../assets/demo2.png";
    else
      this.imgname= "../assets/demo1.png";
  }
}
