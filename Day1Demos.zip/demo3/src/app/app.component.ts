import { Component } from '@angular/core';
import {HttpClient} from '@angular/common/http';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  userarr:Array<Object> ;
  constructor(private http:HttpClient)
  {

  }
  show(){
    console.log("in show ...");
    this.http.get("https://reqres.in/api/users?page=1").subscribe(
      value => {console.log("success"); this.userarr =  value['data']},
      err =>{console.log("error "); console.log(err);}
     );
  }

  title = 'demo3';
}
