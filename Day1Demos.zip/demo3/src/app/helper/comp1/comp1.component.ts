import { Component, OnInit } from '@angular/core';
import {CounterService} from '../counter.service';
@Component({
  selector: 'app-comp1',
  templateUrl: './comp1.component.html',
  styleUrls: ['./comp1.component.css'],
  providers:[CounterService]
})
export class Comp1Component implements OnInit {
  
  constructor(private myservice:CounterService) { 
  
  }
  currentcnt:number=0;
  invoke(){
    this.myservice.incr();
    this.currentcnt = this.myservice.getcount();
  }
  ngOnInit() {
  }

}
