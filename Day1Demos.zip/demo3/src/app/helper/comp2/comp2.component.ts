import { Component, OnInit } from '@angular/core';
import { CounterService } from '../counter.service';

@Component({
  selector: 'app-comp2',
  templateUrl: './comp2.component.html',
  styleUrls: ['./comp2.component.css']
})
export class Comp2Component implements OnInit {

  constructor(private myservice:CounterService) { 
  
  }
  currentcnt:number=0;
  invoke(){
    this.myservice.incr();
    this.currentcnt = this.myservice.getcount();
  }
  ngOnInit() {
  }

}
