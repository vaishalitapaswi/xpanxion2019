import { Component, OnInit } from '@angular/core';
import { CounterService } from '../counter.service';

@Component({
  selector: 'app-comp3',
  templateUrl: './comp3.component.html',
  styleUrls: ['./comp3.component.css']
})
export class Comp3Component implements OnInit {
  constructor(private myservice:CounterService) { 
  
  }
  currentcnt:number=0;
  invoke(){
    this.myservice.incr();
    this.currentcnt = this.myservice.getcount();
  }
  

  ngOnInit() {
  }

}
