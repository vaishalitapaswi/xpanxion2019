import { Component } from '@angular/core';
import {Emp} from './emp';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 emp:Emp = new Emp();
 emparr:Array<Emp> = new Array();
 constructor(){
   this.emparr.push({ "empno": 1, "ename": "aa", "salary": 100 });
   this.emparr.push({ "empno": 2, "ename": "bb", "salary": 200 });
   this.emparr.push({ "empno": 3, "ename": "cc", "salary": 300 });

 }
 delete(row:number):void{
   console.log(row);
   this.emparr.splice(row,1);
 }
 edit(row:number):void{
  this.emp = this.emparr[row];
  
}
 add():void{
   this.emparr.push(this.emp);
   this.emp = new Emp();
 }
}
