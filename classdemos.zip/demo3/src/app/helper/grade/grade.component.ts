import { Component, OnInit, Input, OnChanges, SimpleChanges, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-grade',
  template: "{{grade}} for {{grademarks}}",
  styleUrls: ['./grade.component.css']
})
export class GradeComponent 
        implements OnInit,OnChanges {

  
  @Input() grademarks:number=45;
  grade:string 
  @Output() myevent:EventEmitter<String>= new EventEmitter<String>()
  constructor() {
    console.log("in gradeconstructor " + this.grademarks)
   }
  
  ngOnInit() {
    console.log("in ngOnInit " + this.grademarks)
  
  }
  ngOnChanges(changes: SimpleChanges): void {
    console.log(changes)
    if (this.grademarks > 100)
    {
      this.myevent.emit("Invalid Marks " + this.grademarks)
      console.log("invalid marks, raising event ")
    }
    this.calcgrade()

  }
  calcgrade(){
    if (this.grademarks >= 35)
      this.grade="PASS"
    else
      this.grade = "FAIL"
  }
}
