import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marks',
  templateUrl: './marks.component.html',
  styleUrls: ['./marks.component.css']
})
export class MarksComponent implements OnInit {
  name:String
  marks:number
  method1(str:string)
  {
    console.log("in method1 - myevent handler "  + str)
  }
  constructor() { }

  ngOnInit() {
  }

}
