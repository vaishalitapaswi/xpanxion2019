import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CounterService {
  count:number=0;
  constructor() { 
    console.log(" CounterService constructor")
  }
 public incr(){
    this.count++;
  }
 public getcount():number
  {
    return this.count;
  }
}
