import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {FormsModule} from '@angular/forms'
import { MarksComponent } from './marks/marks.component';
import { GradeComponent } from './grade/grade.component';

@NgModule({
  declarations: [MarksComponent, GradeComponent],
  imports: [
    CommonModule,FormsModule
  ],
  exports:[MarksComponent, GradeComponent]
})
export class HelperModule { }
