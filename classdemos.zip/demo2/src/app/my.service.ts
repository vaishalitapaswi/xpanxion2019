import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MyService {
  counter:number = 0
				
  incr(){
    this.counter++
  }
  getcounter():number{
    return this.counter;
  }
  constructor() { 
    console.log("in MyService Constructor... ");
  }
}
