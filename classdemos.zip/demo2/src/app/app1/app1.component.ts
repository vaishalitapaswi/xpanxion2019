import { Component, OnInit } from '@angular/core';
import { MyService } from '../my.service';

@Component({
  selector: 'app-app1',
  templateUrl: './app1.component.html',
  styleUrls: ['./app1.component.css']
})
export class App1Component implements OnInit {

  invokes(){
    this.my.incr();
  }
  constructor(private my:MyService)
  {
  
  }
  
  ngOnInit() {
  }

}
