import { Component, OnInit } from '@angular/core';
import { MyService } from '../my.service';

@Component({
  selector: 'app-app2',
  templateUrl: './app2.component.html',
  styleUrls: ['./app2.component.css'],
  providers:[MyService]
})
export class App2Component implements OnInit {

  invokes(){
    this.my.incr();
  }
  constructor(private my:MyService)
  {
  
  }
  ngOnInit() {
  }

}
