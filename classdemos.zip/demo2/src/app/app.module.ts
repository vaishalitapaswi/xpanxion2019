import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http'
import {FormsModule} from '@angular/forms';
import { AppComponent } from './app.component';
import { App1Component } from './app1/app1.component';
import { App2Component } from './app2/app2.component';
import { HttpdemoComponent } from './httpdemo/httpdemo.component';

@NgModule({
  declarations: [
    AppComponent,
    App1Component,
    App2Component,
    HttpdemoComponent
  ],
  imports: [
    BrowserModule, HttpClientModule,FormsModule
  ],
  providers: [],
  bootstrap:[HttpdemoComponent]
  //bootstrap: [AppComponent,App1Component,App2Component]
})
export class AppModule { }
