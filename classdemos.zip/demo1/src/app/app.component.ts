import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title:String = 'Vaishali';
  iname:String ="logo1.png"
  imgname:String ="../assets/logo1.png";
  first():void{
    console.log("method1 invoked...")
    this.title = "Xpanxion";
    this.iname = this.iname=="logo1.png"? "logo2.png": "logo1.png"

  }
}
