import { Component, OnInit } from '@angular/core';
import { Emp } from '../emp';

@Component({
  selector: 'app-my',
  templateUrl: './my.component.html',
  styleUrls: ['./my.component.css']
})
export class MyComponent implements OnInit {

  name:String = "start";
  emp:Emp = new Emp()
  emparr:Array<Emp> = new Array()
  constructor() { 
    this.emparr.push( { "empno": 1, "ename": "A", "salary": 11 });
    this.emparr.push( { "empno": 2, "ename": "B", "salary": 22 });
    this.emparr.push( { "empno": 3, "ename": "C", "salary": 33 });

  }

  add():void{
    this.emparr.push(this.emp);
    this.emp = new Emp()
  }
  delete(i:number){
    this.emparr.splice(i,1);
  }
  edit(i:number){
    this.emp = this.emparr[i]
  }
  ngOnInit() {
  }

}
