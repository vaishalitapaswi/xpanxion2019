export class Emp {
    empno:number=1;
    ename:String="A";
    salary:number=11;
}
