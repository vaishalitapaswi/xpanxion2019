import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mydemo',
  templateUrl: './mydemo.component.html',
  styleUrls: ['./mydemo.component.css']
})
export class MydemoComponent {

 cnt:number = 0;
 public add():void{
  console.log("add invoked ... ");
  this.cnt++;
 }

}
