import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';

export class CommonClass implements CanActivate
{
    static authenticated:boolean= true
    
    canActivate(
        route: ActivatedRouteSnapshot, 
        state: RouterStateSnapshot): boolean 
        {
            return CommonClass.authenticated
        }
}

