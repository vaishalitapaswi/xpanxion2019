export class Emp {
    empno:number
    ename:String
    salary:number
}
