import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Emp } from '../emp';

@Component({
  selector: 'app-form2',
  templateUrl: './form2.component.html',
  styleUrls: ['./form2.component.css']
})
export class Form2Component implements OnInit {
  fgrp : FormGroup
  cntrolarr;
  fields:Array<String> 
  e : Emp= new Emp()
  constructor(private fb : FormBuilder) { 
    this.fgrp = fb.group({
      "empnoc":new FormControl(""),
      "enamec": new FormControl("",[Validators.required,Validators.minLength(4), Validators.maxLength(6)]),
      "salaryc":new FormControl("",[Validators.required,Validators.min(100),Validators.max(200)])
    })
    this.cntrolarr = this.fgrp.controls
    this.fields = Object.keys(this.fgrp.controls)
  }
  invoked()
  {
    console.log(this.cntrolarr)
  }
  ngOnInit() {

  }

}
