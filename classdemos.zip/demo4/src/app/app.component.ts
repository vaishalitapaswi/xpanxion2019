import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  name = 'demo4';
  marks:number = 1;
  handleInvalid(str:string){
    console.log("in handleInvalid - event handler ");
    console.log(str);
    
  }
}
