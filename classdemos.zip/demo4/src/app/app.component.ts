import { Component } from '@angular/core';
import { CommonClass } from './CommonClass';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  username:String ="";

  invoke(){
    if (this.username.length>=1)
    {  CommonClass.authenticated= true
      console.log("in invoke if")
    }
  }
  
}
