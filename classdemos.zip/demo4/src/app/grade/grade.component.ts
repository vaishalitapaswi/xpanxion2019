import { Component, OnInit, Input, OnChanges, SimpleChanges, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-grade',
  templateUrl: './grade.component.html',
  styleUrls: ['./grade.component.css']
})
export class GradeComponent 
  implements OnInit, OnChanges {


  
  grade :String = "NOTDECIDED";
  @Input() mrks:number = 20;
  @Output() invalid:EventEmitter<String> = new EventEmitter();
  calcGrade(){
    if (this.mrks >=35)
      this.grade = "PASS"
    else
      this.grade= "FAIL"
    if (this.mrks > 100)
    {
      this.invalid.emit("Invalid Marks " + this.mrks);
    }
  }
  constructor() {
   }

  ngOnInit() {
    
  }
  ngOnChanges(changes: SimpleChanges): void {
    this.calcGrade();
   // console.log(changes);
  }

}
