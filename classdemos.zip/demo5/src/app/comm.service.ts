import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommService {

  constructor(private http:HttpClient) { }

  public postdetails(obj:Object):Observable<any>{
    return this.http.post("https://reqres.in/api/users",obj);
  }
  public sendgeneric(req:HttpRequest<any>):Observable<any>{
    return this.http.request(req);
  }
}
