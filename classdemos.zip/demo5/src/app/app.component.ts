import { Component } from '@angular/core';
import { MyService } from './my.service';
import { HttpClient, HttpRequest } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(private myser:MyService,private http:HttpClient){

  }
  add(){
    this.ans = this.myser.add(this.no1,this.no2)
  }
    show(){
      console.log("in show ...");
     
    }
  
  title = 'demo5';
  no1:number
  no2:number
  ans:number
  
}
