import { Component, OnInit } from '@angular/core';
import { CommService } from '../comm.service';
import { HttpRequest } from '@angular/common/http';
import { post } from 'selenium-webdriver/http';

@Component({
  selector: 'app-comp3',
  templateUrl: './comp3.component.html',
  styleUrls: ['./comp3.component.css']
})
export class Comp3Component implements OnInit {
  usr ={}
  resp ={}
  url = "https://reqres.in/api/users?page=2";
  reqtype ='DELETE'
  constructor(private cs:CommService) 
  { }

  send(){
    this.cs.postdetails(this.usr).subscribe(
      (value)=>{console.log(value); this.resp = value},
      (err)=>{console.log(err);}
    );
  }
  sendgen(){
    let req = new HttpRequest('GET',this.url);
    this.cs.sendgeneric(req).subscribe( (value)=>{console.log(value); this.resp = value},
    (err)=>{console.log(err);});

  }


  ngOnInit() {
  }

}
