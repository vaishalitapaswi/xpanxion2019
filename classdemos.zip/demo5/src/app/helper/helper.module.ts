import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {RouterModule} from '@angular/router';

import { Hc1Component } from './hc1/hc1.component';
import { Hc2Component } from './hc2/hc2.component';


@NgModule({
  declarations: [Hc1Component, Hc2Component],
  imports: [
    CommonModule,RouterModule.forChild([
      {path:'helperhc1',component:Hc1Component    },
      {path:'helperhc2',component:Hc2Component    }
    ])
  ]
})
export class HelperModule { }
