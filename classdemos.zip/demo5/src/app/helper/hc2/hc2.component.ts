import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hc2',
  templateUrl: './hc2.component.html',
  styleUrls: ['./hc2.component.css']
})
export class Hc2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
