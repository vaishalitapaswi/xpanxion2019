import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { Comp1Component } from './comp1/comp1.component';
import { Comp2Component } from './comp2/comp2.component';
import { Comp3Component } from './comp3/comp3.component';

const routes: Routes = [
  {path:'mycomp1',component:Comp1Component},
  {path:'mycomp2',component:Comp2Component},
  {path:'mycomp3',component:Comp3Component},
  {path:'helperpath' , loadChildren:'./helper/helper.module#HelperModule'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{useHash:true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
