import { TestBed } from '@angular/core/testing';

import { MyService } from './my.service';

describe('MyService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MyService = TestBed.get(MyService);
    expect(service).toBeTruthy();
  });
  it('simple add', () => {
    const service: MyService = TestBed.get(MyService);
    expect(service.add(10,20)).toEqual(30)
  });
  it('add with 0', () => {
    const service: MyService = TestBed.get(MyService);
    expect(service.add(10,0)).toEqual(10)
  });
});
