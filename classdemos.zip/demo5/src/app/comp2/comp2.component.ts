import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-comp2',
  templateUrl: './comp2.component.html',
  styleUrls: ['./comp2.component.css']
})
export class Comp2Component implements OnInit {
  formgroupname: FormGroup
  empno:number;
  ename:string;
  salary:number;
  fields:Array<String>=[];

  constructor(formbuilder:FormBuilder) {
    this.formgroupname = formbuilder.group(
      {
        "enocontrol":new FormControl("",Validators.required),
        "enamecontrol":new FormControl("",
          [Validators.required,Validators.minLength(4),Validators.maxLength(10)]),
        "salarycontrol":new FormControl("",[Validators.min(1000),Validators.max(2000)]),
        "emailcontrol" :new FormControl("",Validators.email)
      }
    );
    this.fields = Object.keys(this.formgroupname.controls)
    console.log(this.fields);
   }
   display(){
    console.log(this.formgroupname)
   }
  ngOnInit() {
  }

}
